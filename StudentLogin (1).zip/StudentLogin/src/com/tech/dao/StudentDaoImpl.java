package com.tech.dao;



import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class StudentDaoImpl implements StudentDao {

	@Autowired
	private SessionFactory sessionfactory;
	
	@Override
	public boolean validate(String stu_email, String stu_password) {
		Session session=sessionfactory.openSession();
		boolean userfound=false;
		String HQL="from Student as o where o.stu_email=? and o.stu_password=?";
		
		Query query=session.createQuery(HQL);
		query.setParameter(0, stu_email);
		query.setParameter(1, stu_password);
		List list=query.list();
		if((list!=null)&&(list.size()>0))
		{
			userfound=true;
		
		}
		return userfound;
	}

}
