package com.tech.dao;

public interface StudentDao {

	public boolean validate(String stu_email, String stu_password);
}
