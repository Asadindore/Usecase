package com.tech.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tech.model.Student;
import com.tech.service.StudentService;

@Controller
public class StudentController {
	
	@Autowired
	private StudentService studentService;

	@RequestMapping(value="/")
	public ModelAndView index(Model model)
	{
		model.addAttribute("msg", "Please enter the login details");
		return new ModelAndView("index");
	}
	@RequestMapping(value="/loginform")
	public ModelAndView loginForm(Model model)
	{
		model.addAttribute("msg", "Please enter the login details");
		return new ModelAndView("loginform");
	}

	@RequestMapping(value="/loginprocess", method=RequestMethod.POST)
	public ModelAndView stuValidate(@ModelAttribute("student") Student student)
	{
		boolean userExist=studentService.validate(student.getStu_email(), student.getStu_password());
		if(userExist)
		{
		return new ModelAndView("loginsuccesss");
	
		}else
		{
			return new ModelAndView("index");
		}
}
}
