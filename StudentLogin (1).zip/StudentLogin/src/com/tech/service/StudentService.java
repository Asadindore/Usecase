package com.tech.service;

public interface StudentService {
	public boolean validate(String stu_email, String stu_password);


}
