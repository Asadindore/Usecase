package com.tech.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tech.dao.StudentDao;

@Service("studentService")
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao dao;

	@Override
	public boolean validate(String stu_email, String stu_password) {
	return dao.validate(stu_email, stu_password);
		
	}

}
